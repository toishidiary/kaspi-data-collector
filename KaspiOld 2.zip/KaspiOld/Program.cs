using Spectre.Console;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

internal class Program
{
    private static GoogleSheetsHelper _sheetsHelper;
    private static readonly HttpClient _httpClient = CreateKaspiHttpClient();
    private static readonly Random _random = new Random();
    private static readonly Dictionary<string, List<string>> _positions = new Dictionary<string, List<string>>();

    public static async Task Main(string[] args)
    {
        try
        {
            const string spreadsheetId = "1Aw_92Y4BHWcasM8of-e09ZpS6G4Y8vpFOB_HkEUAA98";
            const string sheetName = "Данные";
            _sheetsHelper = new GoogleSheetsHelper("credentials.json");
            await _sheetsHelper.InitializeAsync();
            // 1. Shift history or snapshot today's positions
            if (await _sheetsHelper.ShiftDatesRightAsync())
            {
                // history was shifted and P1 set to today
            }
            else
            {
                await _sheetsHelper.UpdateTodayPositionsAsync();
            }

            // Flush initial history updates
            await _sheetsHelper.FlushPendingRequestsAsync();

            // 2. Сбор всех данных
            await RunScraperLoopAsync();

            // 3. Финальная запись всех изменений уже была вызвана после RunScraperLoopAsync, не требуется здесь

            AnsiConsole.MarkupLine("[green]Waiting 1 minute and 3 seconds before graceful shutdown...[/]");
            await Task.Delay(TimeSpan.FromSeconds(63)); // Ждём 63 секунды

            AnsiConsole.MarkupLine("[green]Graceful shutdown. Program finished.[/]");
        }
        catch (Exception ex)
        {
            AnsiConsole.WriteLine($"[red]Unhandled error occurred: {ex.Message}[/]");
        }
    }

    private static async Task RunScraperLoopAsync()
    {
        const int maxAttempts = 3;
        int attempt = 0;
        while (true)
        {
            try
            {
                AnsiConsole.Write(new FigletText("Kaspi Scraper").Centered().Color(Color.Blue));

                var productLinks = await AnsiConsole.Status()
                    .StartAsync("Fetching product links...", async ctx =>
                    {
                        return await GetProductLinksForCategory();
                    });

                AnsiConsole.MarkupLine("[blue]Processing products...[/]");
                await ProcessProductLinks(productLinks);

                // После обработки всех продуктов, ДО применения формул:
                await _sheetsHelper.FlushPendingRequestsAsync();

                await AnsiConsole.Status()
                    .StartAsync("Applying formulas...", async ctx =>
                    {
                        var lastRow = await _sheetsHelper.GetLastDataRow();
                        await _sheetsHelper.ApplyFormulasAsync(lastRow);
                        await _sheetsHelper.FlushBatchAsync();
                    });

                // Финальный FlushAllUpdatesAsync уже вызван выше после UpdateTodayPositionsAsync
                AnsiConsole.MarkupLine("[green]Data collection completed successfully![/]");
                break; // Success, exit inner retry loop
            }
            catch (Exception ex)
            {
                attempt++;
                AnsiConsole.WriteLine($"[red]Error in scraper loop: {ex.Message}[/]");
                if (attempt >= maxAttempts)
                {
                    AnsiConsole.MarkupLine($"[red]Maximum retry attempts ({maxAttempts}) reached. Throwing exception.[/]");
                    throw;
                }
                AnsiConsole.MarkupLine($"[yellow]Retrying scraper loop in 5 seconds... (Attempt {attempt}/{maxAttempts})[/]");
                await Task.Delay(5000);
            }
        }
    }

    private static async Task<List<string>> GetProductLinksForCategory()
    {
        var links = new List<string>();
        var itemsByCategory = new Dictionary<string, List<(string Sku, string Id)>>();

        for (int page = 0; page < 100; page++)
        {
            var json = await MakeKaspiRequestAsync(
                $"https://kaspi.kz/yml/product-view/pl/results?page={page}&q=%3Acategory%3ACategories%3AallMerchants%3A17629423%3AavailableInZones%3AMagnum_ZONE5&sort=relevance&c=750000000",
                HttpMethod.Get);
            if (string.IsNullOrEmpty(json)) break;

            dynamic data = JsonConvert.DeserializeObject<dynamic>(json);
            if (data?.data == null || data.data.Count == 0) break;

            foreach (var item in data.data)
            {
                string sku = item.configSku?.ToString();
                string id = item.id?.ToString();
                string category = item.categoryCodes?[0]?.ToString();
                if (string.IsNullOrEmpty(sku) || string.IsNullOrEmpty(id)) continue;

                links.Add(sku);
                if (!itemsByCategory.ContainsKey(category))
                    itemsByCategory[category] = new List<(string, string)>();
                itemsByCategory[category].Add((sku, id));
            }
        }

        await ProcessCategoryPositions(itemsByCategory);
        return links;
    }

    private static async Task ProcessCategoryPositions(Dictionary<string, List<(string Sku, string Id)>> itemsByCategory)
    {
        foreach (var kvp in itemsByCategory)
        {
            var category = kvp.Key;
            var skuList = kvp.Value;

            int page = 0;
            bool hasMore = true;
            var foundPositions = new Dictionary<string, int>();

            while (hasMore)
            {
                var json = await MakeKaspiRequestAsync(
                    $"https://kaspi.kz/yml/product-view/pl/results?page={page}&q=%3Acategory%3ACategories%3AallMerchants%3A{category}%3AavailableInZones%3AMagnum_ZONE5&sort=relevance&c=750000000",
                    HttpMethod.Get);
                if (string.IsNullOrEmpty(json)) break;

                // Debug: print full JSON
                Console.WriteLine($"[DEBUG] Fetched JSON for category {category}, page {page}:\n{json}\n");

                dynamic data = JsonConvert.DeserializeObject<dynamic>(json);
                if (data?.data == null || data.data.Count == 0) break;

                for (int i = 0; i < data.data.Count; i++)
                {
                    var item = data.data[i];
                    string sku = item.configSku?.ToString();
                    if (sku != null && skuList.Any(x => x.Sku == sku))
                    {
                        // Debug: print SKU, page, index, and absolute position
                        int absPos = page * 12 + i + 1;
                        Console.WriteLine($"[DEBUG] Found SKU match: SKU={sku}, page={page}, index={i}, absPos={absPos}");
                        if (!_positions.ContainsKey(sku))
                            _positions[sku] = new List<string>();
                        _positions[sku].Add(absPos.ToString()); // Расчёт позиции на странице (12 товаров на странице)
                    }
                }

                page++;
                hasMore = data.data.Count == 12; // Обычно 12 товаров на страницу
            }
        }
    }

    private static async Task<int> GetProductRankPosition(string targetSku, string cat)
    {
        const int itemsPerPage = 12;
        int currentPosition = 0;

        for (int page = 0; page < 10000; page++)
        {
            var json = await MakeKaspiRequestAsync(
                $"https://kaspi.kz/yml/product-view/pl/results?page={page}&q=%3Acategory%3A{cat}%3AavailableInZones%3AMagnum_ZONE5&sort=relevance&c=750000000",
                HttpMethod.Get);
            if (string.IsNullOrEmpty(json)) break;

            dynamic data = JsonConvert.DeserializeObject<dynamic>(json);
            if (data?.data == null || data.data.Count == 0) break;

            foreach (var item in data.data)
            {
                currentPosition++;
                if (item.configSku?.ToString() == targetSku)
                    return currentPosition;
            }
        }

        return -1;
    }

    private static async Task ProcessProductLinks(List<string> links)
    {
        const int maxDegreeOfParallelism = 10;
        await AnsiConsole.Progress()
            .StartAsync(async ctx =>
            {
                var task = ctx.AddTask("Processing products...", new ProgressTaskSettings { MaxValue = links.Count });
                await Parallel.ForEachAsync(links, new ParallelOptions { MaxDegreeOfParallelism = maxDegreeOfParallelism }, async (sku, cancellationToken) =>
                {
                    try
                    {
                        await ProcessSingleProduct(sku);
                    }
                    catch (Exception ex)
                    {
                        AnsiConsole.WriteLine($"[red]Error processing SKU {sku}: {ex.Message}[/]");
                        // Логируем ошибку с явным ID
                        AnsiConsole.MarkupLine($"[red]Failed to process SKU: {sku}. Exception: {ex}[/]");
                    }
                    finally
                    {
                        task.Increment(1);
                    }
                });
            });
    }

private static async Task ProcessSingleProduct(string productId)
{
    int attempt = 0;
    const int maxAttempts = 200;

    while (attempt < maxAttempts)
    {
        attempt++;

        try
        {
            var productDataTask = MakeKaspiRequestAsync($"https://kaspi.kz/yml/bff-sf/item-page/product/{productId}", HttpMethod.Post);
            var productDataSummaryTask = MakeKaspiRequestAsync($"https://kaspi.kz/yml/creview/rest/misc/product/{productId}/summary", HttpMethod.Get);
            var productDataOfferTask = MakeKaspiRequestAsync($"https://kaspi.kz/yml/offer-view/offers/{productId}", HttpMethod.Post, new { installId = "-1", cityId = "750000000", id = productId });
            var commentsDataTask = MakeKaspiRequestAsync($"https://kaspi.kz/yml/review-view/api/v1/reviews/product/{productId}?filter=COMMENT&limit=5000", HttpMethod.Get);

            await Task.WhenAll(productDataTask, productDataSummaryTask, productDataOfferTask, commentsDataTask);

            var productData = productDataTask.Result;
            var productDataSummary = productDataSummaryTask.Result;
            var productDataOffer = productDataOfferTask.Result;
            var commentsData = commentsDataTask.Result;

            if (string.IsNullOrEmpty(productData))
            {
                AnsiConsole.MarkupLine($"[red]No product data received for productId {productId}. Retrying...[/]");
                await Task.Delay(2000);
                continue;
            }

            dynamic reslt = JsonConvert.DeserializeObject<dynamic>(productData);
            dynamic count_of_rewier = productDataSummary != null ? JsonConvert.DeserializeObject<dynamic>(productDataSummary) : null;
            dynamic result_o_inf = productDataOffer != null ? JsonConvert.DeserializeObject<dynamic>(productDataOffer) : null;
            dynamic com = commentsData != null ? JsonConvert.DeserializeObject<dynamic>(commentsData) : null;

            if (reslt == null || reslt.product == null)
            {
                AnsiConsole.MarkupLine($"[red]Invalid product structure for productId {productId}. Retrying...[/]");
                await Task.Delay(2000);
                continue;
            }

            // Fetch absolute position via API instead of stored dictionary
            var categoryCode = reslt.product.card.promoConditions.categoryCodes?[0]?.ToString() ?? "";
            int absPos = await GetProductRankPosition(productId, categoryCode);
            AnsiConsole.WriteLine($"[DEBUG] Absolute position for {productId} in category {categoryCode}: {absPos}");

            // Лог ID продукта перед отправкой в Google Sheets
            AnsiConsole.MarkupLine($"[grey]Upserting productId to Google Sheets: {productId}[/]");

            // Успех
            var row = CreateDataRow(reslt, count_of_rewier, result_o_inf, com, productId, absPos);
            await _sheetsHelper.UpsertRowByIdAsync(row);
            // No batching; upsert is done inline.
            return;
        }
        catch (Exception ex)
        {
            AnsiConsole.WriteLine($"[red]Error processing productId {productId}: {ex.Message}[/]");
            AnsiConsole.MarkupLine($"[yellow]Restarting script for {productId} automatically...[/]");
            // Логируем стек для диагностики
            AnsiConsole.WriteLine(ex.ToString());
            await Task.Delay(2000);
        }
    }

    // Если дошли сюда — все попытки неудачные
    AnsiConsole.MarkupLine($"[red]Failed to process productId {productId} after {maxAttempts} attempts.[/]");
    System.IO.File.AppendAllText("failed_products.txt", productId + Environment.NewLine);
    await Task.Delay(2000);
}

private static IList<object> CreateDataRow(dynamic prod, dynamic sum, dynamic offer, dynamic com, string productId, int absPos)
{
    int posNum = absPos;
    bool hasPosition = absPos > 0;
    string positionToday = hasPosition ? absPos.ToString() : "";

    var row = new List<object>
    {
        (prod?.product?.card?.name ?? "").ToString(),               // A: Название товара
        (prod?.product?.card?.id ?? "").ToString(),                 // B: ID товара
        (offer?.offers?[0]?.price ?? "").ToString(),                // C: Цена
        $"https://kaspi.kz/shop/c/{FormatString(prod?.product?.card?.promoConditions?.categoryCodes?[0]?.ToString())}/", // D: Ссылка на категорию
        $"https://kaspi.kz/shop{prod?.product?.card?.shopLink}",     // E: Ссылка на товар
        (prod?.product?.card?.category?[0] ?? "").ToString(),        // F: Группа товаров
    };

    int categoryCount = prod?.product?.card?.category?.Count ?? 0;
    row.Add(categoryCount > 1 ? prod.product.card.category[categoryCount - 1].ToString() : ""); // G: Подгруппа
    row.Add((prod?.product?.card?.promoConditions?.brand ?? "").ToString());                    // H: Бренд
    row.Add((sum?.data?.global ?? "").ToString());                                              // I: Рейтинг

    int reviewCountFromSummary = 0;
    int negativeCommentsCount = 0;

    if (sum?.data?.reviewsCount != null)
    {
        reviewCountFromSummary = (int)sum.data.reviewsCount;
    }

    if (com?["data"] is JArray dataArray)
    {
        negativeCommentsCount = dataArray.Count(item => (int?)item["rating"] <= 2);
    }

    row.Add(reviewCountFromSummary.ToString()); // J: Количество отзывов
    row.Add(negativeCommentsCount.ToString());  // K: Количество негативных отзывов

    // !!! ВАЖНО: Теперь точно вставляем позицию на сегодня в колонку L (индекс 11)
    row.Add(hasPosition ? positionToday : "[нет позиции]"); // L: Позиция категории сегодня

    // M: Минимум
    row.Add("=MIN(PROW:UROW)");

    // N: Страница категории
    row.Add(posNum > 0 ? ((posNum - 1) / 12 + 1).ToString() : "более 300");

    // O: Смещение позиции
    row.Add("=PROW-LROW");

    // P → далее даты истории
    for (int i = 0; i < 30; i++) row.Add(""); // Заполняем пустыми ячейками под даты истории

    return row;
}

    // Отключено: код для сохранения истории в JSON-файлы, диагностики или позиции

    // HTTP helper
    private static async Task<string> MakeKaspiRequestAsync(string url, HttpMethod method, object body = null, int maxRetries = 7)
    {
        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            if (attempt > 1) await Task.Delay(3000);

            HttpResponseMessage resp;
            if (method == HttpMethod.Get)
                resp = await _httpClient.GetAsync(url);
            else
            {
                var json = JsonConvert.SerializeObject(body ?? new { });
                resp = await _httpClient.PostAsync(url, new StringContent(json, System.Text.Encoding.UTF8, "application/json"));
            }

            if (resp.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                if (attempt == maxRetries) SaveForbiddenLink(url);
                continue;
            }

            try { resp.EnsureSuccessStatusCode(); }
            catch { continue; }

            return await resp.Content.ReadAsStringAsync();
        }
        return null;
    }

private static void SaveForbiddenLink(string url) => System.IO.File.AppendAllText("forbidden_links.txt", url + Environment.NewLine);

public static string FormatString(object input) =>
  string.IsNullOrEmpty(input?.ToString()) ? "" : input.ToString().Replace(" ", "%20").ToLower();

public static int ProcessNumber(int num)
{
    return num > 0 ? num : 0;
}

private static HttpClient CreateKaspiHttpClient()
{
    var client = new HttpClient(new HttpClientHandler { AutomaticDecompression = System.Net.DecompressionMethods.GZip });
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    client.DefaultRequestHeaders.Add("Accept-Language", "ru-RU");
    client.DefaultRequestHeaders.Add("Cookie", "ks.tg=43; k_stat=...; kaspi.storefront.cookie.city=750000000");
    client.DefaultRequestHeaders.Add("Referer", "https://kaspi.kz/shop/");
    client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0");
    client.DefaultRequestHeaders.Add("X-KS-City", "750000000");
    return client;
}
        }