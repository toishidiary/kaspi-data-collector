using System.Linq;
using Google;
using System.Net;
using SheetColor = Google.Apis.Sheets.v4.Data.Color;
using Spectre.Console;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.IO;
using System;

public class GoogleSheetsHelper
{
    private static readonly string LogFilePath = "kaspi_log.txt";

    private readonly DriveService _driveService;
    private readonly SheetsService _sheetsService;
    private readonly List<Request> _pendingRequests = new();
    public bool HistoryWasShiftedToday => _historyWasShiftedToday;
    private bool _historyWasShiftedToday = false;
    private string _spreadsheetId;
    private string _currentSheetName;
    private int? _sheetId;
    private List<IList<object>> _batchData = new List<IList<object>>();
    private Dictionary<string, int> _idToRow = new Dictionary<string, int>();
    private int _nextRow = 2; // First data row index after header
    private const int AutoFlushThreshold = 500; // Number of rows to accumulate before auto-flush
    // Maximum number of days to keep in history columns
    private const int MaxHistoryDays = 30;

    private static readonly object _logLock = new object();

private static void Log(string message)
{
    var timestamp = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}]";
    var safeTimestamp = timestamp.Replace("[", "[[").Replace("]", "]]");

    lock (_logLock)
    {
        var plainText = $"{timestamp} {StripMarkupTags(message)}";
        System.IO.File.AppendAllText(LogFilePath, plainText + Environment.NewLine);
    }

    try
    {
        Spectre.Console.AnsiConsole.MarkupLine($"[grey]{safeTimestamp}[/] {message}");
    }
    catch (Exception)
    {
        Spectre.Console.AnsiConsole.WriteLine($"{timestamp} {StripMarkupTags(message)}");
    }
}

private static string StripMarkupTags(string text)
{
    return text.Replace("[blue]", "").Replace("[green]", "").Replace("[/]", "");
}

    public GoogleSheetsHelper(string credentialsPath)
    {
        GoogleCredential credential;
        using (var fileStream = new System.IO.FileStream(credentialsPath, System.IO.FileMode.Open, System.IO.FileAccess.Read))
        {
            credential = GoogleCredential.FromStream(fileStream)
                .CreateScoped(SheetsService.Scope.Spreadsheets, DriveService.Scope.Drive);
        }

        _sheetsService = new SheetsService(new BaseClientService.Initializer()
        {
            HttpClientInitializer = credential,
            ApplicationName = "Kaspi Data Collector",
        });

        _driveService = new DriveService(new BaseClientService.Initializer()
        {
            HttpClientInitializer = credential,
            ApplicationName = "Kaspi Data Collector",
        });
    }

    public async Task InitializeAsync()
    {
        _spreadsheetId = "1Aw_92Y4BHWcasM8of-e09ZpS6G4Y8vpFOB_HkEUAA98";

        const string FixedSheetName = "Copy of Данные";

        var spreadsheet = await _sheetsService.Spreadsheets.Get(_spreadsheetId).ExecuteAsync();
        var existing = spreadsheet.Sheets.FirstOrDefault(s => s.Properties.Title == FixedSheetName);
        if (existing != null)
        {
            _sheetId = existing.Properties.SheetId;
            _currentSheetName = FixedSheetName;
            Log($"[yellow]Using existing sheet: {FixedSheetName}[/]");
        }
        else
        {
            var addReq = new Request
            {
                AddSheet = new AddSheetRequest { Properties = new SheetProperties { Title = FixedSheetName } }
            };
            var batchAdd = new BatchUpdateSpreadsheetRequest { Requests = new List<Request> { addReq } };
            var resp = await _sheetsService.Spreadsheets.BatchUpdate(batchAdd, _spreadsheetId).ExecuteAsync();
            _sheetId = resp.Replies[0].AddSheet.Properties.SheetId;
            _currentSheetName = FixedSheetName;
            Log($"[green]Created sheet: {FixedSheetName}[/]");
            await InitializeHeadersAsync();
        }

        // Now that _currentSheetName and _sheetId are set:
        // ShiftDatesRightAsync is now called externally in Main
        
        // Protect history columns P–AS (columns 16–[16+MaxHistoryDays))
        var lastRowForProtect = await GetLastDataRow();
        var protectRequest = new Request
        {
            AddProtectedRange = new AddProtectedRangeRequest
            {
                ProtectedRange = new ProtectedRange
                {
                    Range = new GridRange
                    {
                        SheetId            = _sheetId.Value,
                        StartRowIndex      = 1,                   // Skip header row
                        EndRowIndex        = lastRowForProtect,   // Cover all data rows
                        StartColumnIndex   = 15,                  // Column P (0-based)
                        EndColumnIndex     = 15 + MaxHistoryDays  // Through AS
                    },
                    WarningOnly = true,
                    Description = "Historical data protection"
                }
            }
        };
        await _sheetsService.Spreadsheets
            .BatchUpdate(new BatchUpdateSpreadsheetRequest { Requests = new List<Request> { protectRequest } }, _spreadsheetId)
            .ExecuteAsync();

        await ShareSpreadsheetWithUser("tkrujka@gmail.com");

        var idResp = await _sheetsService.Spreadsheets.Values
            .Get(_spreadsheetId, $"{_currentSheetName}!B2:B")
            .ExecuteAsync();
        if (idResp.Values != null)
        {
            _idToRow = idResp.Values
                .Select((r, i) => (id: r[0].ToString(), row: i + 2))
                .ToDictionary(x => x.id, x => x.row);
            _nextRow = _idToRow.Values.DefaultIfEmpty(1).Max() + 1;
        }
    }

    private async Task InitializeHeadersAsync()
    {
        var headers = new List<object>
        {
            "Название", "id Товара", "Цена", "Подгруппа", "Ссылка на товар",
            "Группа товаров", "Подгруппа", "Бренд", "Рейтинг",
            "Кол. отзывов", "Кол. негативных отзывов", "Позиция категории сегодня", "Минимум", 
            "Страница категории сегодня", "Смещение позиции сегодня"
        };
        // Add headers for the last MaxHistoryDays days
        for (int i = 1; i <= MaxHistoryDays; i++)
        {
            headers.Add(DateTime.Now.AddDays(-i).ToString("dd.MM.yyyy"));
        }
        
        headers.Add(" ");

        AddRowToBatch(headers);
        await FlushBatchAsync();
    }

    public void AddRowToBatch(IList<object> rowData)
    {
        _batchData.Add(rowData);

        if (_batchData.Count >= AutoFlushThreshold)
        {
            try
            {
                FlushBatchAsync().Wait();
            }
            catch (Exception ex)
            {
                Log($"Error flushing batch: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Обновляет строку по совпадающему ID (столбец B) или добавляет новую, если такого ID нет.
    /// При обновлении подсвечивает всю строку зелёным ➔ затем снова белым ➔ затем голубым.
    /// Все обновления и подсветки добавляются в _pendingRequests и отправляются батчем через FlushPendingRequestsAsync.
    /// </summary>
    public async Task UpsertRowByIdAsync(IList<object> rowData)
    {
        string id = rowData.Count > 1 ? rowData[1]?.ToString() : null;
        int rowNum;
        if (id != null && _idToRow.TryGetValue(id, out rowNum))
        {
            // 1. First batch - update all data EXCEPT history columns (P-AS)
            var updateRequest = new Request
            {
                UpdateCells = new UpdateCellsRequest
                {
                    Start = new GridCoordinate
                    {
                        SheetId = _sheetId.Value,
                        RowIndex = rowNum - 1,
                        ColumnIndex = 0
                    },
                    Rows = new List<RowData>
                    {
                        new RowData
                        {
                            Values = rowData.Take(15) // Only columns A-O
                                .Select(v => new CellData {
                                    UserEnteredValue = new ExtendedValue {
                                        StringValue = v?.ToString() ?? ""
                                    }
                                }).ToList()
                        }
                    },
                    Fields = "userEnteredValue"
                }
            };
            _pendingRequests.Add(updateRequest);

            // 3. Highlight changes
            _pendingRequests.AddRange(GetHighlightRequests(rowNum));

            // 4. No immediate flush here; batching is handled externally.

            // 5. Reset background after delay (as separate batch)
            _ = ResetRowBackgroundAsync(rowNum);
        }
        else
        {
            // Add new row (restrict history columns to empty)
            var newRowData = rowData.Take(15).ToList();
            for (int i = 0; i < MaxHistoryDays; i++)
                newRowData.Add(""); // Empty protected history columns

            AddRowToBatch(newRowData);
        }
    }

    /// <summary>
    /// Returns highlight requests for a given row (green, then white, then cyan).
    /// </summary>
    private IEnumerable<Request> GetHighlightRequests(int rowNum)
    {
        // Green highlight
        yield return new Request
        {
            RepeatCell = new RepeatCellRequest
            {
                Range = new GridRange
                {
                    SheetId = _sheetId.Value,
                    StartRowIndex = rowNum - 1,
                    EndRowIndex = rowNum,
                    StartColumnIndex = 0,
                    EndColumnIndex = 15 + MaxHistoryDays
                },
                Cell = new CellData
                {
                    UserEnteredFormat = new CellFormat
                    {
                        BackgroundColor = new SheetColor { Red = 0.8f, Green = 1f, Blue = 0.8f }
                    }
                },
                Fields = "userEnteredFormat.backgroundColor"
            }
        };
        // White reset
        yield return new Request
        {
            RepeatCell = new RepeatCellRequest
            {
                Range = new GridRange
                {
                    SheetId = _sheetId.Value,
                    StartRowIndex = rowNum - 1,
                    EndRowIndex = rowNum,
                    StartColumnIndex = 0,
                    EndColumnIndex = 15 + MaxHistoryDays
                },
                Cell = new CellData
                {
                    UserEnteredFormat = new CellFormat
                    {
                        BackgroundColor = new SheetColor { Red = 1f, Green = 1f, Blue = 1f }
                    }
                },
                Fields = "userEnteredFormat.backgroundColor"
            }
        };
        // Cyan highlight
        yield return new Request
        {
            RepeatCell = new RepeatCellRequest
            {
                Range = new GridRange
                {
                    SheetId = _sheetId.Value,
                    StartRowIndex = rowNum - 1,
                    EndRowIndex = rowNum,
                    StartColumnIndex = 0,
                    EndColumnIndex = 15 + MaxHistoryDays
                },
                Cell = new CellData
                {
                    UserEnteredFormat = new CellFormat
                    {
                        BackgroundColor = new SheetColor { Red = 0f, Green = 1f, Blue = 1f }
                    }
                },
                Fields = "userEnteredFormat.backgroundColor"
            }
        };
    }


public async Task FlushPendingRequestsAsync()
{
    if (_pendingRequests.Count == 0)
        return;

    var batchUpdateRequest = new BatchUpdateSpreadsheetRequest
    {
        Requests = _pendingRequests
    };

    int retryCount = 0;
    while (true)
    {
        try
        {
            await _sheetsService.Spreadsheets.BatchUpdate(batchUpdateRequest, _spreadsheetId).ExecuteAsync();
            break;
        }
        catch (GoogleApiException ex) when (ex.HttpStatusCode == (HttpStatusCode)429 && retryCount < 5)
        {
            retryCount++;
            var delay = TimeSpan.FromSeconds(Math.Pow(2, retryCount));
            Log($"[yellow]Rate limit hit, retrying in {delay.TotalSeconds}s (attempt {retryCount})[/]");
            await Task.Delay(delay);
        }
    }

    _pendingRequests.Clear();
}

    /// <summary>
    /// Alias for flushing all pending update requests.
    /// </summary>
    public async Task FlushAllUpdatesAsync()
    {
        await FlushPendingRequestsAsync();
    }

    public async Task FlushBatchAsync()
    {
        if (_batchData.Count == 0) return;

        var range = $"{_currentSheetName}!A:AT";
        var valueRange = new ValueRange { Values = _batchData };

        try
        {
            var appendRequest = _sheetsService.Spreadsheets.Values.Append(
                valueRange, _spreadsheetId, range);
            appendRequest.ValueInputOption =
                SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum.USERENTERED;

            await appendRequest.ExecuteAsync();
            _batchData.Clear();
        }
        catch (Exception ex)
        {
            Log($"Error flushing batch: {ex.Message}");
        }
    }


    public async Task ApplyFormulasAsync(int lastRow)
    {
        if (lastRow < 2) return; // No data rows

        var requests = new List<Request>();

        for (int row = 2; row <= lastRow; row++)
        {
            // Minimum formula in column M (index 12)
            requests.Add(new Request
            {
                RepeatCell = new RepeatCellRequest
                {
                    Range = new GridRange
                    {
                        SheetId = _sheetId,
                        StartRowIndex = row - 1,
                        EndRowIndex = row,
                        StartColumnIndex = 12,
                        EndColumnIndex = 13
                    },
                    Cell = new CellData
                    {
                        UserEnteredValue = new ExtendedValue { FormulaValue = $"=MIN(P{row}:U{row})" },
                        UserEnteredFormat = new CellFormat { NumberFormat = new NumberFormat { Type = "NUMBER" } }
                    },
                    Fields = "userEnteredValue,userEnteredFormat.numberFormat"
                }
            });

            // Page category formula in column N (index 13)
            requests.Add(new Request
            {
                RepeatCell = new RepeatCellRequest
                {
                    Range = new GridRange
                    {
                        SheetId = _sheetId,
                        StartRowIndex = row - 1,
                        EndRowIndex = row,
                        StartColumnIndex = 13,
                        EndColumnIndex = 14
                    },
                    Cell = new CellData
                    {
                        UserEnteredValue = new ExtendedValue { FormulaValue = $"=IF(L{row}=\"\", \"\", CEILING(L{row}/12, 1))" }
                    },
                    Fields = "userEnteredValue"
                }
            });

            // Offset formula in column O (index 14)
            requests.Add(new Request
            {
                RepeatCell = new RepeatCellRequest
                {
                    Range = new GridRange
                    {
                        SheetId = _sheetId,
                        StartRowIndex = row - 1,
                        EndRowIndex = row,
                        StartColumnIndex = 14,
                        EndColumnIndex = 15
                    },
                    Cell = new CellData
                    {
                        UserEnteredValue = new ExtendedValue { FormulaValue = $"=P{row}-L{row}" },
                        UserEnteredFormat = new CellFormat { NumberFormat = new NumberFormat { Type = "NUMBER" } }
                    },
                    Fields = "userEnteredValue,userEnteredFormat.numberFormat"
                }
            });
        }

        var batchUpdateRequest = new BatchUpdateSpreadsheetRequest
        {
            Requests = requests
        };

        await _sheetsService.Spreadsheets.BatchUpdate(batchUpdateRequest, _spreadsheetId).ExecuteAsync();
    }

public async Task<bool> ShiftDatesRightAsync()
{
    // Prevent multiple shifts in the same run
    if (_historyWasShiftedToday)
        return false;

    // Load all sheet data
    var allData = await GetAllRowsAsync();
    if (allData.Count < 2 || _sheetId == null)
        return false;

    // Parse dates
    string todayStr = DateTime.Now.ToString("dd.MM.yyyy");
    DateTime today = DateTime.Now.Date;

    // Read current P1
    var header = new List<object>(allData[0]);
    string currentP = header.Count > 15 ? header[15]?.ToString() : null;
    if (currentP == todayStr)
    {
        Log("[grey]P1 is already today, no shift needed[/]");
        return false;
    }
    if (!DateTime.TryParseExact(currentP, "dd.MM.yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime pDate))
    {
        Log($"[yellow]P1 value '{currentP}' is not a valid date, skipping shift[/]");
        return false;
    }

    // Compute how many days to shift
    int daysDiff = (int)(today - pDate).TotalDays;
    if (daysDiff <= 0 || daysDiff > MaxHistoryDays)
    {
        Log($"[yellow]Date in P1 is {daysDiff} days old, outside valid range, skipping shift[/]");
        return false;
    }

    // Prepare new in-memory table
    var newData = new List<IList<object>>(allData.Count);

    // --- Shift header row ---
    var newHeader = new List<object>(header);
    // Ensure we have enough columns
    while (newHeader.Count < 16 + MaxHistoryDays)
        newHeader.Add(null);
    // Shift existing history columns P.. backwards by daysDiff
    for (int col = 15 + MaxHistoryDays; col >= 15 + daysDiff; col--)
        newHeader[col] = newHeader[col - daysDiff];
    // Fill new dates for the first daysDiff columns
    for (int i = 0; i < daysDiff; i++)
        newHeader[15 + i] = today.AddDays(-i).ToString("dd.MM.yyyy");
    newData.Add(newHeader);

    // --- Shift each data row ---
    for (int rowIdx = 1; rowIdx < allData.Count; rowIdx++)
    {
        var row = new List<object>(allData[rowIdx]);
        // Ensure full row length
        while (row.Count < 16 + MaxHistoryDays)
            row.Add(null);

        // Shift history columns for this row
        for (int col = 15 + MaxHistoryDays; col >= 15 + daysDiff; col--)
            row[col] = row[col - daysDiff];

        // Clear values for days with no data (between today and shifted snapshot)
        for (int i = 1; i < daysDiff; i++)
        {
            row[15 + i] = null;
        }

        newData.Add(row);
    }

    // Write back entire sheet in one atomic update
    await UpdateAllDataAsync(newData);

    _historyWasShiftedToday = true;
    Log($"[green]Shifted history by {daysDiff} days and updated P1 to {todayStr}[/]");

    // After shifting, update today's snapshot in P from L
    await UpdateTodayPositionsAsync();
    await FlushPendingRequestsAsync();
    return true;
}

public async Task UpdateTodayPositionsAsync()
{
    // Copy column L→P for today’s snapshot
int lastRow = await GetLastDataRow();
if (lastRow < 2) return;

var copyRequest = new Request {
  CopyPaste = new CopyPasteRequest {
    Source = new GridRange {
      SheetId = _sheetId.Value,
      StartRowIndex   = 1,         // row 2 (skip header)
      EndRowIndex     = lastRow,   // down to last data row
      StartColumnIndex= 11,        // column L (0-based)
      EndColumnIndex  = 12
    },
    Destination = new GridRange {
      SheetId = _sheetId.Value,
      StartRowIndex   = 1,
      EndRowIndex     = lastRow,
      StartColumnIndex= 15,        // column P
      EndColumnIndex  = 16
    },
    PasteType = "PASTE_VALUES"
  }
};

var batch = new BatchUpdateSpreadsheetRequest {
  Requests = new List<Request> { copyRequest }
};
await _sheetsService.Spreadsheets
    .BatchUpdate(batch, _spreadsheetId)
    .ExecuteAsync();
}

    /// <summary>
    /// Подсвечивает строки, где сегодняшняя позиция (L) отличается от вчерашней (P).
    /// </summary>
    public async Task HighlightPositionDifferencesAsync()
    {
        var allRows = await GetAllRowsAsync();
        if (allRows.Count < 2) return;

        var requests = new List<Request>();
        for (int i = 1; i < allRows.Count; i++)
        {
            var row = allRows[i];
            if (row.Count > 15 && row.Count > 11)
            {
                var oldVal = row[15]?.ToString() ?? "";
                var newVal = row[11]?.ToString() ?? "";
                if (!oldVal.Equals(newVal, StringComparison.Ordinal))
                {
                    requests.Add(new Request
                    {
                        RepeatCell = new RepeatCellRequest
                        {
                            Range = new GridRange
                            {
                                SheetId = _sheetId.Value,
                                StartRowIndex = i,
                                EndRowIndex   = i + 1,
                                StartColumnIndex = 11, // Column L
                                EndColumnIndex   = 12
                            },
                            Cell = new CellData
                            {
                                UserEnteredFormat = new CellFormat
                                {
                                    BackgroundColor = new SheetColor { Red = 1f, Green = 0.9f, Blue = 0.6f }
                                }
                            },
                            Fields = "userEnteredFormat.backgroundColor"
                        }
                    });
                }
            }
        }
        if (requests.Count > 0)
        {
            var batch = new BatchUpdateSpreadsheetRequest { Requests = requests };
            await _sheetsService.Spreadsheets.BatchUpdate(batch, _spreadsheetId).ExecuteAsync();
        }
    }

    private async Task ShareSpreadsheetWithUser(string email)
    {
        var permission = new Permission
        {
            Type = "user",
            Role = "writer",
            EmailAddress = email
        };

        var request = _driveService.Permissions.Create(permission, _spreadsheetId);
        request.SendNotificationEmail = false;
        await request.ExecuteAsync();
    }

    public async Task<int> GetLastDataRow()
    {
        var range = $"{_currentSheetName}!A:A";
        var response = await _sheetsService.Spreadsheets.Values.Get(_spreadsheetId, range).ExecuteAsync();
        return response.Values?.Count ?? 1;
    }

    public async Task<IList<IList<object>>> GetAllRowsAsync()
    {
        var range = $"{_currentSheetName}";
        var response = await _sheetsService.Spreadsheets.Values.Get(_spreadsheetId, range).ExecuteAsync();
        return response.Values ?? new List<IList<object>>();
    }
    /// <summary>
/// Alias for GetAllRowsAsync to satisfy calls to GetAllDataAsync.
/// </summary>
private Task<IList<IList<object>>> GetAllDataAsync()
{
    return GetAllRowsAsync();
}

    /// <summary>
    /// Updates all rows in the sheet, targeting the explicit range A1:AT{rowCount}.
    /// </summary>
    public async Task UpdateAllRowsAsync(IList<IList<object>> rows)
    {
        int rowCount = rows.Count;
        var range = $"{_currentSheetName}!A1:AT{rowCount}";
        var valueRange = new ValueRange { Values = rows };
        var updateRequest = _sheetsService.Spreadsheets.Values.Update(valueRange, _spreadsheetId, range);
        updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
        await updateRequest.ExecuteAsync();
    }

    /// <summary>
    /// Updates all data in the sheet, targeting the explicit range based on data size.
    /// </summary>
    private async Task UpdateAllDataAsync(IList<IList<object>> data)
    {
        int rowCount = data.Count;
        int colCount = data.FirstOrDefault()?.Count ?? 0;
        string endColumn = GetColumnLetter(colCount);
        string range = $"{_currentSheetName}!A1:{endColumn}{rowCount}";
        var valueRange = new ValueRange { Values = data };
        var updateRequest = _sheetsService.Spreadsheets.Values.Update(valueRange, _spreadsheetId, range);
        updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
        await updateRequest.ExecuteAsync();
    }

    /// <summary>
    /// After a delay, resets the background of a single row to white.
    /// </summary>
    private async Task ResetRowBackgroundAsync(int rowNum)
    {
        // Wait for 1 minute
        await Task.Delay(TimeSpan.FromMinutes(1));

        // Build request to reset the row background to white
        var request = new Request
        {
            RepeatCell = new RepeatCellRequest
            {
                Range = new GridRange
                {
                    SheetId = _sheetId.Value,
                    StartRowIndex = rowNum - 1,
                    EndRowIndex = rowNum,
                    StartColumnIndex = 0,
                    EndColumnIndex = 45 // adjust if your sheet has different width
                },
                Cell = new CellData
                {
                    UserEnteredFormat = new CellFormat
                    {
                        BackgroundColor = new SheetColor { Red = 1f, Green = 1f, Blue = 1f }
                    }
                },
                Fields = "userEnteredFormat.backgroundColor"
            }
        };
        var batchUpdate = new BatchUpdateSpreadsheetRequest { Requests = new List<Request> { request } };
        await _sheetsService.Spreadsheets.BatchUpdate(batchUpdate, _spreadsheetId).ExecuteAsync();
    }

    /// <summary>
    /// Resets all rows' history background to white, but only if header P1 is today's date.
    /// </summary>
    public async Task SetAllRowsWhiteBackgroundAsync()
    {
        // 0) Flush any pending updates before white reset
        await FlushPendingRequestsAsync();

        await Task.Delay(TimeSpan.FromMinutes(1));

        // 1) Only reset history if header P1 is today's date
        var headerRow = await GetHeaderRowAsync();
        string today = DateTime.Now.ToString("dd.MM.yyyy");
        if (headerRow == null || headerRow.Count <= 15 || headerRow[15]?.ToString() != today)
        {
            Log("[grey]SetAllRowsWhiteBackgroundAsync: Header P1 is not today, skipping white reset.[/]");
            return;
        }

        // Compute last data row
        int lastRow = await GetLastDataRow();
        if (lastRow < 2) return;

        // Build request to clear background in history columns (P:AT)
        var clearHistoryBg = new Request
        {
            RepeatCell = new RepeatCellRequest
            {
                Range = new GridRange
                {
                    SheetId = _sheetId.Value,
                    StartRowIndex = 1,
                    EndRowIndex = lastRow,
                    StartColumnIndex = 15,
                    EndColumnIndex = 15 + MaxHistoryDays
                },
                Cell = new CellData
                {
                    UserEnteredFormat = new CellFormat
                    {
                        BackgroundColor = new SheetColor { Red = 1f, Green = 1f, Blue = 1f }
                    }
                },
                Fields = "userEnteredFormat.backgroundColor"
            }
        };

        var batch = new BatchUpdateSpreadsheetRequest
        {
            Requests = new List<Request> { clearHistoryBg }
        };
        await _sheetsService.Spreadsheets.BatchUpdate(batch, _spreadsheetId).ExecuteAsync();
        Log("[grey]SetAllRowsWhiteBackgroundAsync: History columns background reset to white.[/]");
    }

    private async Task<IList<object>> GetHeaderRowAsync()
    {
        var range = $"{_currentSheetName}!A1:AT1";
        var response = await _sheetsService.Spreadsheets.Values.Get(_spreadsheetId, range).ExecuteAsync();
        return response.Values?.FirstOrDefault();
    }
    private static string GetColumnLetter(int columnNumber)
    {
        int dividend = columnNumber;
        string columnName = "";
        while (dividend > 0)
        {
            int modulo = (dividend - 1) % 26;
            columnName = Convert.ToChar(65 + modulo) + columnName;
            dividend = (dividend - modulo) / 26;
        }
        return columnName;
    }
}